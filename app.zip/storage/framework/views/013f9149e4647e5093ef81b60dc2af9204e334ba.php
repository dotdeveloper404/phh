<?php
    $breadcrumbs = [
        [
            'name' => 'Dashboard',
            'link' => route('dashboard'),
        ],
        [
            'name' => 'Leads',
            'link' => false,
        ],
    ];
    $title = 'Contact Leads';
?>



<?php $__env->startSection('title', $title); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        .delete {
            height: 40px;
            width: 40px;
            border-radius: 50%;
        }
        .swal2-popup .swal2-styled {
            margin: 0 10px !important;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="p-5">
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr class="fw-bold border-bottom">
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Message</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(count($leads)): ?>
                            <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="align-middle">
                                    <td><?php echo e($lead->name); ?></td>
                                    <td><?php echo e($lead->email); ?></td>
                                    <td><?php echo e($lead->phone); ?></td>
                                    <td><?php echo e($lead->message); ?></td>
                                    <td>
                                        <a class="delete bg-danger d-flex align-items-center justify-content-center"
                                            href="javascript:void(0)" data-url="<?php echo e(route('contact.destroy', $lead->id)); ?>">
                                            <i class="fas fa-trash-alt text-white"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr class="align-middle">
                                <td colspan="5" class="text-center">
                                    <b>
                                        No leads created
                                    </b>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $('.delete').on('click', function() {
            swal.fire({
                icon: 'warning',
                title: 'Confirm delete',
                text: 'Are you sure to proceed?',
                showCancelButton: true,
            }).then((result) => {
                if (result.isConfirmed) {
                    axios.delete($(this).data('url'))
                        .then(response => response.data)
                        .then(data => {
                            if (data.success) {
                                window.location.reload()
                            } else {
                                swal.fire({
                                    icon: 'error',
                                    title: 'Oops...',
                                    text: 'Something went wrong!',
                                })
                            }
                        })
                        .catch(err => {
                            swal.fire({
                                icon: 'error',
                                title: 'Oops...',
                                text: 'Something went wrong!',
                            })
                        })
                }
            })


        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', [
    'title' => $title,
    'breadcrumbs' => $breadcrumbs,
    'addButton' => true,
    'btn' => [
        'text' => 'Back',
        'link' => route('dashboard'),
    ],
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Suraqa\phh\resources\views/dashboard/leads/index.blade.php ENDPATH**/ ?>