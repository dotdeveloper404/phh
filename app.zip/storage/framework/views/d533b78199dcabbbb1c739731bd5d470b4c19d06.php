<section class="deals-section position-relative">
    <div class="container">
        <div class="row">
            <div class="col-xxl-12 col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <h2><img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="Logo"> <br><span>Gallagher’s</span></h2>
            </div>
        </div>
        <div class="row">
            <div class="col-xxl-12 col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <ul class="deals-list">
                    <?php $__currentLoopData = $deals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <div class="list-data">
                                <div class="deals-img">
                                    <img src="<?php echo e(asset("uploads/$d->image")); ?>" alt="Product image">
                                </div>
                                <div class="deals-content">
                                    <h3><?php echo e($d->name); ?></h3>
                                    <?php echo $d->description; ?>

                                    <span>$<?php echo e($d->price); ?></span>
                                    <form action="<?php echo e(route('cart.store')); ?>" method="POST" class="d-inline"
                                        id="add-to-cart-<?php echo e($d->id); ?>">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" value="<?php echo e($d->id); ?>" name="id">
                                        <input type="hidden" value="<?php echo e($d->name); ?>" name="name">
                                        <input type="hidden" value="<?php echo e($d->price); ?>" name="price">
                                        <input type="hidden" value="<?php echo e($d->image); ?>" name="image">
                                        <input type="hidden" value="1" name="quantity">
                                        <a href="javascript:void(0);" class="btn_add_to_cart"
                                            onclick="$('#add-to-cart-<?php echo e($d->id); ?>').submit()">
                                            <i class="fas fa-shopping-basket"></i> Add to Cart
                                        </a>
                                    </form>
                                </div>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
</section>
<?php /**PATH D:\Suraqa\phh\resources\views/components/deals-section.blade.php ENDPATH**/ ?>