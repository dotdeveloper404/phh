

<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
    <section class="top-header">
        <div class="container">
            <div class="row">
                <div class="col-xxl-12 col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="parallax-wrapper">
                        <div class="parallax-img scrollblock" id="parallax-head">
                            <img src="<?php echo e(asset('assets/images/large-chips-1.png')); ?>" alt="" class="chip1"
                                data-aos="fade-down" data-aos-duration="1000" data-aos-delay="3s">
                            <img src="<?php echo e(asset('assets/images/small-ships-blur.png')); ?>" alt="" class="chip2">
                            <img src="<?php echo e(asset('assets/images/burger.png')); ?>" alt="" class="burger"
                                data-aos="zoom-in-left" data-aos-duration="2000">
                            <img src="<?php echo e(asset('assets/images/wyn-glass.png')); ?>" alt="" class="mug"
                                data-aos="fade-left" data-aos-duration="2000" data-aos-delay="4s">
                            <img src="<?php echo e(asset('assets/images/small-ships-blur.png')); ?>" alt="" class="chip5"
                                data-aos="zoom-in-left" data-aos-duration="1500">
                            <img src="<?php echo e(asset('assets/images/small-ships.png')); ?>" alt="" class="chip3"
                                data-aos="zoom-out-right" data-aos-duration="1500">
                            <img src="<?php echo e(asset('assets/images/large-chips-blur.png')); ?>" alt="" class="chip4">
                        </div>
                        <div class="parallax-content">
                            <h1>Happy <br> Hour</h1>
                            <a href="#">Don't Be late</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="about-section">
        <div class="container">
            <div class="row">
                <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                    <img src="<?php echo e(asset('assets/images/about-img.png')); ?>" alt="" data-aos="zoom-in"
                        class="img-fluid">
                </div>
                <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                    <div class="about-wrapper" data-aos="fade-left">
                        <h2>What is <br><span>pre happy hour</span></h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut
                            labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco
                            laboris nisi ut aliquip ex ea commodo consequat.</p>
                        <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
                            pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt
                            mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem
                            accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore
                            veritatis et quasi architecto beatae vitae dicta sunt explicabo. </p>
                        <a href="#" class="view-btn">View Deals</a>
                        <a href="#" class="available-btn">Available Now</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="howitwork-section beer-section">
        <div class="container">
            <div class="row">
                <div class="col-xxl-12 col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="howitwork-wrapper">
                        <h2 data-aos="fade-right">How to <br><span>Pre Happy Hour</span></h2>
                        <ul data-aos="fade-down">
                            <li>
                                <span>Step1:</span>
                                <i class="fas fa-sign-in-alt"></i>
                                <p>Sign up and Register</p>
                            </li>
                            <li>
                                <span>Step2:</span>
                                <i class="fas fa-utensils"></i>
                                <p>Select bar/restaurant</p>
                            </li>
                            <li>
                                <span>Step3:</span>
                                <i class="fas fa-hamburger"></i>
                                <p>Select Drinks and Food</p>
                            </li>
                            <li>
                                <span>Step4:</span>
                                <i class="fas fa-credit-card"></i>
                                <p>Pay</p>
                            </li>
                            <li>
                                <span>Step5:</span>
                                <i class="fas fa-envelope"></i>
                                <p>Receive text / email with 6 digit code</p>
                            </li>
                            <li>
                                <span>Step6:</span>
                                <i class="fas fa-id-card"></i>
                                <p>Present to ID and provide 6 <br>digit code to server or bartender</p>
                            </li>
                            <li>
                                <span>Step7:</span>
                                <i class="fas fa-couch"></i>
                                <p>Relax and Enjoy</p>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="beer-section">
        <div class="container">
            <div class="row">
                <div class="col-xxl-7 col-xl-7 col-lg-7 col-md-7 col-sm-12 col-12">
                    <div class="beer-content">
                        <h2>Beer &amp; Much More <br><span>DISCOVER OUR MENUS WITH BEER INCLUDED</span></h2>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut
                            labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco
                            laboris nisi ut aliquip ex ea commodo consequat.</p>
                        <a href="#">View Deals</a>
                    </div>
                </div>
                <div class="col-xxl-5 col-xl-5 col-lg-5 col-md-5 col-sm-12 col-12">
                    <div class="beer-img-content">
                        <div class="circle">hurry UP! <br>GRAB THE <br> BEERS DEALS</div>
                        <img src="<?php echo e(asset('assets/images/beer-mug-bottle.png')); ?>" alt="">
                    </div>
                </div>
            </div>
        </div>
    </section>

    

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.deals-section','data' => ['deals' => $deals]] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('deals-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['deals' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($deals)]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <section class="testimonials-section">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 background-img">&amp;</div>
                <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 background-color">
                    <div class="review-wrapper">
                        <h2>Client <br> <span>Reviews</span></h2>
                        <div class="review-carousel">
                            <ul class="bxslider">
                                <li>
                                    <p>‘Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                                        incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
                                        exercitation</p>
                                    <h3>Jhony</h3>
                                    <span>Lorem ipsum dolor sit amet,</span>
                                </li>
                                <li>
                                    <p>‘Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                                        incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
                                        exercitation</p>
                                    <h3>Jhony</h3>
                                    <span>Lorem ipsum dolor sit amet,</span>
                                </li>
                                <li>
                                    <p>‘Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                                        incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
                                        exercitation</p>
                                    <h3>Jhony</h3>
                                    <span>Lorem ipsum dolor sit amet,</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php if(session()->has('order_placed')): $__env->startPush( 'scripts'); ?>
    <?php
        $data = Session::get('order_placed');
    ?>

    <script>
        $(function() {
            <?php if($data['success']): ?>
                swal.fire({
                    icon: 'success',
                    title: 'Success',
                    html: "<?php echo e($data['message']); ?><br/><b>Code: <?php echo e($data['code']); ?></b>"
                })
            <?php else: ?>
                swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: "<?php echo e($data['message']); ?>"
                })
                console.log("<?php echo e($data['dev_msg']); ?>");
            <?php endif; ?>
        })
    </script>
<?php $__env->stopPush(); endif; ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Suraqa\phh\resources\views/frontend/index.blade.php ENDPATH**/ ?>