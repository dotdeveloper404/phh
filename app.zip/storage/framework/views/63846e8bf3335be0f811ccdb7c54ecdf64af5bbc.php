<div>
    <h1>An order has been placed</h1>

    <h3>Details</h3>
    <p><b>User name:</b> <?php echo e($order->user->name); ?></p>
    <p><b>Order code:</b> <?php echo e($order->code); ?></p>
    <p><b>Order total:</b> <?php echo e($order->total); ?></p>
    <h3><b>Order items:</b></h3>
    <table>
        <thead>
            <tr>
                <th>Deal name</th>
                <th></th>
                <th>Price</th>
                <th></th>
                <th>Quantity</th>
                <th></th>
                <th>Sub total</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i->name); ?></td>
                    <td></td>
                    <td><?php echo e($i->price); ?></td>
                    <td></td>
                    <td><?php echo e($i->quantity); ?></td>
                    <td></td>
                    <td><?php echo e($i->subtotal); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</div><?php /**PATH D:\Suraqa\phh\resources\views/emails/order-placed.blade.php ENDPATH**/ ?>