<?php
    $breadcrumbs = [
        [
            'name' => 'Dashboard',
            'link' => route('dashboard'),
        ],
        [
            'name' => 'Roles',
            'link' => route('roles.index'),
        ],
        [
            'name' => 'Listing',
            'link' => false,
        ],
    ];
    $title = 'Roles';
?>

<?php $__env->startSection('title', $title); ?>




<?php $__env->startSection('content'); ?>
    


    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <p class="mb-0"><?php echo e($message); ?></p>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>


    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>No</th>
                <th>Name</th>
                <th width="280px">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="align-middle">
                    <td><?php echo e(++$i); ?></td>
                    <td><?php echo e($role->name); ?></td>
                    <td>
                        <a class="btn btn-info" href="<?php echo e(route('roles.show', $role->id)); ?>">Show</a>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-edit')): ?>
                            <a class="btn btn-primary" href="<?php echo e(route('roles.edit', $role->id)); ?>">Edit</a>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role-delete')): ?>
                            <?php echo Form::open(['method' => 'DELETE', 'route' => ['roles.destroy', $role->id], 'style' => 'display:inline']); ?>

                            <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

                            <?php echo Form::close(); ?>

                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>


    <?php echo $roles->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', [
    'title' => $title,
    'breadcrumbs' => $breadcrumbs,
    'addButton' => true,
    'btn' => [
        'text' => 'Add Role',
        'link' => route('roles.create'),
    ],
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Suraqa\phh\resources\views/dashboard/roles/index.blade.php ENDPATH**/ ?>