

<?php $__env->startSection('title', 'Cart'); ?>

<?php $__env->startSection('content'); ?>
    <section class="deals-section">
        <div class="container">
            <div class="row">
                <div class="col-xxl-12 col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <h2> <br><span>CART</span></h2>
                </div>
            </div>
            <div class="row">
                <div class="col-xxl-12 col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <ul class="deals-list">
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <main class="my-8">
        <div class="container px-6 mx-auto cartlist">
            <div class="flex justify-center my-6">
                <div class="p-4 flex flex-col w-full p-8 text-gray-800 bg-white shadow-lg pin-r pin-y md:w-4/5 lg:w-4/5">
                    <?php if($message = Session::get('success')): ?>
                    <?php endif; ?>
                    <div class="alert alert-success alert-dismissible" role="alert">
                        
                        asddas
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>

                    <div class="flex-1">
                        <table class="table table-striped" cellspacing="0">
                            <thead class="thead-dark">
                                <tr class="h-12 uppercase">
                                    <th class="hidden md:table-cell"></th>
                                    <th class="text-left">Name</th>
                                    <th class="pl-5 text-left lg:text-right lg:pl-0">
                                        <span class="lg:hidden" title="Quantity">Qtd</span>
                                        <span class="hidden lg:inline">Quantity</span>
                                    </th>
                                    <th class="hidden text-right md:table-cell"> price</th>
                                    <th class="hidden text-right md:table-cell"> Remove </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="hidden pb-4 md:table-cell">
                                            <a href="#">
                                                <img src="<?php echo e($item->attributes->image); ?>" class="w-20 rounded"
                                                    alt="Thumbnail">
                                            </a>
                                        </td>
                                        <td>
                                            <a href="#">
                                                <p class="mb-2 md:ml-4"><?php echo e($item->name); ?></p>

                                            </a>
                                        </td>
                                        <td class="justify-center mt-6 md:justify-end md:flex">
                                            <div class="h-10 w-28">
                                                <div class="relative flex flex-row w-full h-8">

                                                    <form action="<?php echo e(route('cart.update')); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                                                        <input type="number" name="quantity" value="<?php echo e($item->quantity); ?>"
                                                            class="" />
                                                        <button type="submit"
                                                            class="btn_update_to_cart btn btn-primary">update</button>
                                                    </form>

                                                </div>
                                            </div>
                                        </td>
                                        <td class="hidden text-right md:table-cell">
                                            <span class="text-sm font-medium lg:text-base">
                                                $<?php echo e($item->price); ?>

                                            </span>
                                        </td>
                                        <td class="hidden text-right md:table-cell">
                                            <form action="<?php echo e(route('cart.remove')); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" value="<?php echo e($item->id); ?>" name="id">
                                                <button class="btn btn-danger">x</button>
                                            </form>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div style="float:right;">
                            Total: $<?php echo e(Cart::getTotal()); ?>


                            <form action="<?php echo e(route('cart.clear')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-danger">Remove All Cart</button>

                            </form>
                            <a href="<?php echo e(route('checkout')); ?>" class="btn btn-primary">Checkout</a>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </main>

    <section class="deals-section">
        <div class="container">
            <div class="row">
                <div class="col-xxl-12 col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <h2><img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt=""> <br><span>Gallagher’s</span></h2>
                </div>
            </div>
            <div class="row">
                <div class="col-xxl-12 col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <ul class="deals-list">
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <div class="list-data">
                                    <div class="deals-img">
                                        <img src="<?php echo e(asset($product->image)); ?>" alt="">
                                    </div>
                                    <div class="deals-content">
                                        <h3><?php echo e($product->name); ?></h3>
                                        <p><?php echo e($product->description); ?></p>
                                        <span>$<?php echo e($product->price); ?></span>
                                        <form action="<?php echo e(route('cart.store')); ?>" method="POST"
                                            enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" value="<?php echo e($product->id); ?>" name="id">
                                            <input type="hidden" value="<?php echo e($product->name); ?>" name="name">
                                            <input type="hidden" value="<?php echo e($product->price); ?>" name="price">
                                            <input type="hidden" value="<?php echo e($product->image); ?>" name="image">
                                            <input type="hidden" value="1" name="quantity">
                                            <button class="px-4 py-2 btn_add_to_cart"><i
                                                    class="fas fa-shopping-basket"></i>Add To Cart</button>
                                        </form>
                                    </div>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </ul>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php if(session()->has('error')): $__env->startPush( 'scripts'); ?>
    <script>
        $(function() {
            swal.fire({
                icon: 'error',
                title: 'Error',
                text: "<?php echo e(session()->get('error')); ?>"
            })
        })
    </script>
<?php $__env->stopPush(); endif; ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Suraqa\phh\resources\views/cart.blade.php ENDPATH**/ ?>