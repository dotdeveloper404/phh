<?php $order = app('App\Services\OrderWidgetService'); ?>

<!DOCTYPE html>

<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <title><?php echo $__env->yieldContent('title'); ?> | <?php echo e(config('app.name')); ?></title>
    <meta charset="utf-8" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="shortcut icon" href="<?php echo e(asset('dashboard-assets/media/logos/favicon.ico')); ?>" />
    <!-- begin::Fonts(mandatory for all pages) -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Inter:300,400,500,600,700" />
    <!--end::Fonts-->

    <!--begin::Global Stylesheets Bundle(mandatory for all pages)-->
    <link href="<?php echo e(asset('dashboard-assets/plugins/global/plugins.bundle.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('dashboard-assets/css/style.bundle.css')); ?>" rel="stylesheet" type="text/css" />
    <!--end::Global Stylesheets Bundle-->

    <link rel="stylesheet" type="text/css" src="<?php echo e(asset('dashboard-assets/plugins/DataTables/datatables.min.css')); ?>">


    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>

    <style>
        .dataTables_filter {
            text-align: end
        }

        .dataTables_filter label {
            text-align: start
        }

        #DataTables_Table_0_paginate
        .pagination {
            justify-content: end
        }
    </style>

    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body id="kt_app_body" data-kt-app-layout="dark-sidebar" data-kt-app-header-fixed="false"
    data-kt-app-sidebar-enabled="true" data-kt-app-sidebar-fixed="true" data-kt-app-sidebar-hoverable="true"
    data-kt-app-sidebar-push-header="true" data-kt-app-sidebar-push-toolbar="true"
    data-kt-app-sidebar-push-footer="true" data-kt-app-toolbar-enabled="true" class="app-default">

    <!--begin::App-->
    <div class="d-flex flex-column flex-root app-root" id="kt_app_root">

        <!--begin::Page-->
        <div class="app-page flex-column flex-column-fluid" id="kt_app_page">

            <!--begin::Header-->
            <div id="kt_app_header" class="app-header">

                <!--begin::Header container-->
                <div class="app-container container-fluid d-flex align-items-stretch justify-content-between"
                    id="kt_app_header_container">

                    <!--begin::Header wrapper-->
                    <div class="d-flex align-items-stretch justify-content-between flex-lg-grow-1"
                        id="kt_app_header_wrapper">

                        <!--begin::Orders widgets-->
                        <div class="app-navbar flex-shrink-0">
                            <div class="btn btn-primary my-4 me-2">
                                Total Orders <span class="badge bg-danger ms-2"><?php echo e($order->totalOrders()); ?></span>
                            </div>

                            <div class="btn btn-primary my-4 mx-2">
                                Pending Orders <span
                                    class="badge bg-danger ms-2"><?php echo e($order->totalPendingOrders()); ?></span>
                            </div>

                            <div class="btn btn-primary my-4 ms-2">
                                Completed Orders <span
                                    class="badge bg-danger ms-2"><?php echo e($order->totalCompletedOrders()); ?></span>
                            </div>

                        </div>
                        <!--end::Orders widgets-->

                        <!--begin::User menu-->
                        <div class="app-navbar flex-shrink-0">

                            <!--begin::User menu-->
                            <div class="app-navbar-item ms-1 ms-lg-3" id="kt_header_user_menu_toggle">

                                <!--begin::Menu wrapper-->
                                <div class="cursor-pointer symbol symbol-35px symbol-md-50px"
                                    data-kt-menu-trigger="{default: 'click', lg: 'hover'}" data-kt-menu-attach="parent"
                                    data-kt-menu-placement="bottom-end">
                                    <img src="<?php echo e(asset('dashboard-assets/media/avatars/300-1.jpg')); ?>" alt="user" />
                                </div>

                                <!--begin::User account menu-->
                                <div class="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-800 menu-state-bg menu-state-color fw-semibold py-4 fs-6 w-275px"
                                    data-kt-menu="true">

                                    <!--begin::Menu item-->
                                    <div class="menu-item px-3">
                                        <div class="menu-content d-flex align-items-center px-3">

                                            <!--begin::Avatar-->
                                            <div class="symbol symbol-50px me-5">
                                                <img alt="Logo"
                                                    src="<?php echo e(asset('dashboard-assets/media/avatars/300-1.jpg')); ?>" />
                                            </div>
                                            <!--end::Avatar-->

                                            <!--begin::Username-->
                                            <div class="d-flex flex-column">
                                                <div class="fw-bold d-flex align-items-center fs-5">
                                                    <?php echo e(auth()->user()->name); ?>

                                                    <span class="badge badge-light-success fw-bold fs-8 px-2 py-1 ms-2">
                                                        <?php echo e(auth()->user()->getRoleNames()->first()); ?>

                                                    </span>
                                                </div>
                                                <span class="fw-semibold text-muted text-hover-primary fs-7">
                                                    <?php echo e(auth()->user()->email); ?>

                                                </span>
                                            </div>
                                            <!--end::Username-->

                                        </div>
                                    </div>
                                    <!--end::Menu item-->

                                    <!--begin::Menu separator-->
                                    <div class="separator my-2"></div>
                                    <!--end::Menu separator-->

                                    <!--begin::Menu item-->
                                    <div class="menu-item px-5">
                                        <a href="#" class="menu-link px-5">My Profile</a>
                                    </div>
                                    <!--end::Menu item-->

                                    <!--begin::Menu item-->
                                    <div class="menu-item px-5">
                                        <a href="javascript:void(0)" onclick="$('#logoutForm').submit()"
                                            class="menu-link px-5">Sign Out</a>
                                    </div>
                                    <!--end::Menu item-->

                                </div>
                                <!--end::User account menu-->

                                <!--end::Menu wrapper-->
                            </div>
                            <!--end::User menu-->

                        </div>
                        <!--end::User menu-->

                    </div>
                    <!--end::Header wrapper-->

                </div>
                <!--end::Header container-->


            </div>
            <!--end::Header-->

            <!--begin::Wrapper-->
            <div class="app-wrapper flex-column flex-row-fluid" id="kt_app_wrapper">

                <!--begin::Sidebar-->
                <div id="kt_app_sidebar" class="app-sidebar flex-column" data-kt-drawer="true"
                    data-kt-drawer-name="app-sidebar" data-kt-drawer-activate="{default: true, lg: false}"
                    data-kt-drawer-overlay="true" data-kt-drawer-width="225px" data-kt-drawer-direction="start">

                    <!--begin::Logo-->
                    <div class="app-sidebar-logo justify-content-center p-6" id="kt_app_sidebar_logo"
                        style="height: unset !important">

                        <!--begin::Logo image-->
                        <a href="<?php echo e(route('home.index')); ?>">

                            <img alt="Logo" src="<?php echo e(asset('dashboard-assets/media/logos/default-logo.png')); ?>"
                                class="w-125px app-sidebar-logo-default" />
                            <img alt="Logo" src="<?php echo e(asset('dashboard-assets/media/logos/small-logo.png')); ?>"
                                class="h-20px w-30px app-sidebar-logo-minimize" />

                        </a>
                        <!--end::Logo image-->

                        <!--begin::Sidebar toggle-->
                        <div id="kt_app_sidebar_toggle"
                            class="app-sidebar-toggle btn btn-icon btn-shadow btn-sm btn-color-muted btn-active-color-primary body-bg h-30px w-30px position-absolute top-50 start-100 translate-middle rotate"
                            data-kt-toggle="true" data-kt-toggle-state="active" data-kt-toggle-target="body"
                            data-kt-toggle-name="app-sidebar-minimize">

                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr079.svg-->
                            <span class="svg-icon svg-icon-2 rotate-180">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path opacity="0.5"
                                        d="M14.2657 11.4343L18.45 7.25C18.8642 6.83579 18.8642 6.16421 18.45 5.75C18.0358 5.33579 17.3642 5.33579 16.95 5.75L11.4071 11.2929C11.0166 11.6834 11.0166 12.3166 11.4071 12.7071L16.95 18.25C17.3642 18.6642 18.0358 18.6642 18.45 18.25C18.8642 17.8358 18.8642 17.1642 18.45 16.75L14.2657 12.5657C13.9533 12.2533 13.9533 11.7467 14.2657 11.4343Z"
                                        fill="currentColor" />
                                    <path
                                        d="M8.2657 11.4343L12.45 7.25C12.8642 6.83579 12.8642 6.16421 12.45 5.75C12.0358 5.33579 11.3642 5.33579 10.95 5.75L5.40712 11.2929C5.01659 11.6834 5.01659 12.3166 5.40712 12.7071L10.95 18.25C11.3642 18.6642 12.0358 18.6642 12.45 18.25C12.8642 17.8358 12.8642 17.1642 12.45 16.75L8.2657 12.5657C7.95328 12.2533 7.95328 11.7467 8.2657 11.4343Z"
                                        fill="currentColor" />
                                </svg>
                            </span>
                            <!--end::Svg Icon-->

                        </div>
                        <!--end::Sidebar toggle-->

                    </div>
                    <!--end::Logo-->

                    <!--begin::sidebar menu-->
                    <div class="app-sidebar-menu overflow-hidden flex-column-fluid">

                        <!--begin::Menu wrapper-->
                        <div id="kt_app_sidebar_menu_wrapper" class="app-sidebar-wrapper hover-scroll-overlay-y my-5"
                            data-kt-scroll="true" data-kt-scroll-activate="true" data-kt-scroll-height="auto"
                            data-kt-scroll-dependencies="#kt_app_sidebar_logo, #kt_app_sidebar_footer"
                            data-kt-scroll-wrappers="#kt_app_sidebar_menu" data-kt-scroll-offset="5px"
                            data-kt-scroll-save-state="true">

                            <!--begin::Menu-->
                            <div class="menu menu-column menu-rounded menu-sub-indention px-3"
                                id="#kt_app_sidebar_menu" data-kt-menu="true" data-kt-menu-expand="false">

                                
                                <div class="menu-item">
                                    <a class="menu-link <?php if (\Illuminate\Support\Facades\Blade::check('route', 'dashboard')): ?> active <?php endif; ?>"
                                        href="<?php echo e(route('dashboard')); ?>">
                                        <span class="menu-icon">
                                            <span class="svg-icon svg-icon-2">
                                                <i class="bi bi-grid-fill fs-2"></i>
                                            </span>
                                        </span>
                                        <span class="menu-title">Dashboard</span>
                                    </a>
                                </div>

                                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Admin')): ?>

                                    
                                    <div class="menu-item">
                                        <a class="menu-link <?php if (\Illuminate\Support\Facades\Blade::check('route', 'users.index')): ?> active <?php endif; ?>"
                                            href="<?php echo e(route('users.index')); ?>">
                                            <span class="menu-icon">
                                                <span class="svg-icon svg-icon-2">
                                                    <i class="fa fa-users fs-2"></i>
                                                </span>
                                            </span>
                                            <span class="menu-title">Users</span>
                                        </a>
                                    </div>

                                    
                                    <div class="menu-item">
                                        <a class="menu-link <?php if (\Illuminate\Support\Facades\Blade::check('route', 'roles.index')): ?> active <?php endif; ?>"
                                            href="<?php echo e(route('roles.index')); ?>">
                                            <span class="menu-icon">
                                                <span class="svg-icon svg-icon-2">
                                                    <i class="bi bi-person-badge-fill fs-2"></i>
                                                </span>
                                            </span>
                                            <span class="menu-title">Roles</span>
                                        </a>
                                    </div>

                                    
                                    <div class="menu-item">
                                        <a class="menu-link <?php if (\Illuminate\Support\Facades\Blade::check('route', 'contact.index')): ?> active <?php endif; ?>"
                                            href="<?php echo e(route('contact.index')); ?>">
                                            <span class="menu-icon">
                                                <span class="svg-icon svg-icon-2">
                                                    <i class="fa-solid fa-calendar-check fs-2"></i>
                                                </span>
                                            </span>
                                            <span class="menu-title">Leads</span>
                                        </a>
                                    </div>

                                <?php endif; ?>

                                
                                <div class="menu-item">
                                    <a class="menu-link <?php if (\Illuminate\Support\Facades\Blade::check('route', 'deals.index')): ?> active <?php endif; ?>"
                                        href="<?php echo e(route('deals.index')); ?>">
                                        <span class="menu-icon">
                                            <span class="svg-icon svg-icon-2">
                                                <i class="bi bi-bag-plus-fill fs-2"></i>
                                            </span>
                                        </span>
                                        <span class="menu-title">Deals</span>
                                    </a>
                                </div>

                                
                                <div class="menu-item">
                                    <a class="menu-link <?php if (\Illuminate\Support\Facades\Blade::check('route', 'order.index')): ?> active <?php endif; ?>"
                                        href="<?php echo e(route('order.index')); ?>">
                                        <span class="menu-icon">
                                            <span class="svg-icon svg-icon-2">
                                                <i class="bi bi-cart-check-fill fs-2"></i>
                                            </span>
                                        </span>
                                        <span class="menu-title">Orders</span>
                                    </a>
                                </div>


                                
                                

                                <!--Simple link-->
                                
                                <!--Simple link-->

                                <!--Dropdown Link-->
                                
                                <!--Dropdown Link-->

                            </div>
                            <!--end::Menu-->

                        </div>
                        <!--end::Menu wrapper-->

                    </div>
                    <!--end::sidebar menu-->

                    <!--begin::Footer-->
                    <div class="app-sidebar-footer flex-column-auto pt-2 pb-6 px-6" id="kt_app_sidebar_footer">
                        <a href="javascript:void(0)" onclick="$('#logoutForm').submit()"
                            class="btn btn-flex flex-center btn-custom btn-primary overflow-hidden text-nowrap px-0 h-40px w-100">
                            <span class="btn-label me-3">Logout</span>
                            <i class="bi bi-box-arrow-right"
                                style="font-size: 15px; padding-right: 0 !important;"></i>
                        </a>
                    </div>
                    <form action="<?php echo e(route('logout')); ?>" method="post" id="logoutForm"><?php echo csrf_field(); ?></form>
                    <!--end::Footer-->

                </div>
                <!--end::Sidebar-->

                <!--begin::Main-->
                <div class="app-main flex-column flex-row-fluid" id="kt_app_main">

                    <!--begin::Content wrapper-->
                    <div class="d-flex flex-column flex-column-fluid">

                        <!--begin::Toolbar-->
                        <div id="kt_app_toolbar" class="app-toolbar py-3 py-lg-6">

                            <!--begin::Toolbar container-->
                            <div id="kt_app_toolbar_container"
                                class="app-container container-fluid d-flex flex-stack">

                                <!--begin::Page title-->
                                <div class="page-title d-flex flex-column justify-content-center flex-wrap me-3">

                                    <!--begin::Title-->
                                    <h1
                                        class="page-heading d-flex text-dark fw-bold flex-column justify-content-center my-0">
                                        <?php echo e($title ?? ''); ?>

                                    </h1>
                                    <!--end::Title-->

                                    <!--begin::Breadcrumb-->
                                    <?php if(isset($breadcrumbs)): ?>
                                        <ul class="breadcrumb breadcrumb-dot fw-semibold fs-7 my-0 pt-1">
                                            <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($b['link']): ?>
                                                    <li class="breadcrumb-item pe-3">
                                                        <a href="<?php echo e($b['link']); ?>"
                                                            class="text-primary text-hover-dark"><?php echo e($b['name']); ?></a>
                                                    </li>
                                                <?php else: ?>
                                                    <li class="breadcrumb-item pe-3 text-muted"><?php echo e($b['name']); ?></li>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    <?php endif; ?>
                                    <!--end::Breadcrumb-->

                                </div>
                                <!--end::Page title-->

                                <?php if(isset($addButton) && $addButton): ?>
                                    <div>
                                        <a class="btn btn-primary" href="<?php echo e($btn['link']); ?>">
                                            <?php echo e($btn['text']); ?>

                                        </a>
                                    </div>
                                <?php endif; ?>

                            </div>
                            <!--end::Toolbar container-->

                        </div>
                        <!--end::Toolbar-->

                        <!--begin::Content-->
                        <div id="kt_app_content" class="app-content flex-column-fluid bg-white">

                            <!--begin::Content container-->
                            <div id="kt_app_content_container" class="app-container container-fluid">

                                <?php echo $__env->yieldContent('content'); ?>

                            </div>
                            <!--end::Content container-->

                        </div>
                        <!--end::Content-->

                    </div>
                </div>

            </div>
            <!--end::Wrapper-->

        </div>
        <!--end::Page-->

    </div>
    <!--end::App-->

    <!--begin::Global Javascript Bundle(mandatory for all pages)-->
    <script src="<?php echo e(asset('dashboard-assets/plugins/global/plugins.bundle.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard-assets/js/scripts.bundle.js')); ?>"></script>
    <!--end::Global Javascript Bundle-->

    <script src="<?php echo e(asset('dashboard-assets/plugins/DataTables/datatables.min.js')); ?>"></script>

    <?php echo $__env->yieldPushContent('scripts'); ?>
    <script>
        $(function() {
            $('.datatable').DataTable();
        })
    </script>
</body>
<?php /**PATH D:\Suraqa\phh\resources\views/layouts/app.blade.php ENDPATH**/ ?>