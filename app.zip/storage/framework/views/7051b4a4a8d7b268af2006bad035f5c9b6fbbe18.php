<header>
    <div class="container">
        <div class="row align-items-center">
            <div class="col-xxl-3 col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12">
                <div class="logo">
                    <a href="<?php echo e(route('home.index')); ?>">
                        <img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="Pre Happy Hour" class="img-fluid">
                    </a>
                </div>
            </div>

            <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                <nav>
                    <div class="three">
                        <div class="hamburger" id="hamburger-1">
                            <span class="line"></span>
                            <span class="line"></span>
                            <span class="line"></span>
                        </div>
                    </div>
                    <ul class="menu">
                        <li><a href="<?php echo e(route('home.index')); ?>">Home</a></li>
                        <li><a href="<?php echo e(route('home.howitworks')); ?>">How to Pre Happy Hour</a></li>
                        <li><a href="<?php echo e(route('home.bestdeals')); ?>">Best Deals</a></li>
                        <li><a href="<?php echo e(route('home.partners')); ?>">Partners</a></li>
                        <li><a href="<?php echo e(route('home.contact')); ?>">Contact Us</a></li>
                    </ul>
                </nav>
            </div>

            <div class="col-xxl-3 col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12 align-self-center">
                <div class="search-login">
                    <?php if(auth()->guard()->check()): ?>
                        <div class="dropdown login_register">
                            <a class="btn btn-secondary dropdown-toggle login" href="#" role="button"
                                id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-user"></i>
                                <?php echo e(auth()->user()->name); ?>

                            </a>

                            <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Admin|Restaurant')): ?>
                                    <li><a class="dropdown-item" href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                                <?php else: ?>
                                    <li><a class="dropdown-item" href="#">My Orders</a></li>
                                <?php endif; ?>
                                <li><a class="dropdown-item" href="#" onclick="$('#logout-form').submit()">Logout</a></li>
                                <form action="<?php echo e(route('logout')); ?>" method="post" id="logout-form"><?php echo csrf_field(); ?></form>
                            </ul>

                            <a href="<?php echo e(route('cart.list')); ?>" class="register position-relative">
                                <i class="fas fa-cart-shopping"></i>
                                <span class="position-absolute top-0 start-100 translate-middle badge rounded-circle bg-danger">
                                    <?php echo e(Cart::getTotalQuantity()); ?>

                                </span>
                            </a>
                        </div>
                    <?php else: ?>
                        <div class="login_register">
                            <a href="<?php echo e(route('login')); ?>" class="login">
                                <i class="fas fa-user"></i>
                                Login
                            </a>

                            <a href="<?php echo e(route('register')); ?>" class="register">
                                <i class="fas fa-user"></i>
                                Register
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</header>
<?php /**PATH D:\Suraqa\phh\resources\views/partials/header.blade.php ENDPATH**/ ?>