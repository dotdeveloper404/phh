<?php
    $title = 'Deals';
    $breadcrumbs = [
        [
            'name' => 'Dashboard',
            'link' => route('dashboard'),
        ],
        [
            'name' => $title,
            'link' => false,
        ],
        [
            'name' => 'Listing',
            'link' => false,
        ],
    ];
    
?>



<?php $__env->startSection('title', $title); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        .delete,
        .edit {
            height: 40px;
            width: 40px;
            border-radius: 50%;
        }

        .image {
            width: 50px;
            height: 50px;
        }

        .swal2-popup .swal2-styled {
            margin: 0 10px !important;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="p-5">
            <?php if($alert = Session::get('alert')): ?>
                <div class="alert alert-<?php echo e($alert['type']); ?> alert-dismissible fade show" role="alert">
                    <strong><?php echo e($alert['msg']); ?></strong>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Image</th>
                            <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Admin')): ?>
                                <th>Restaurant</th>
                            <?php endif; ?>
                            <th>Name</th>
                            <th>Price</th>
                            <th>Description</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(count($deals)): ?>
                            <?php $__currentLoopData = $deals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="align-middle">
                                    <td>
                                        <div class="image">
                                            <img src='<?php echo e(asset("uploads/$d->image")); ?>' alt="" class="h-100 w-100">
                                        </div>
                                    </td>
                                    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Admin')): ?>
                                        <td><?php echo e($d->restaurant->name); ?></td>
                                    <?php endif; ?>
                                    <td><?php echo e($d->name); ?></td>
                                    <td><?php echo e($d->price); ?></td>
                                    <td><?php echo $d->description; ?></td>
                                    <td>
                                        <div class="d-flex">
                                            <a class="delete bg-danger d-flex align-items-center justify-content-center"
                                                href="javascript:void(0)">
                                                <i class="fas fa-trash-alt text-white"></i>
                                                <form action="<?php echo e(route('deals.destroy', $d->id)); ?>" method="post">
                                                    <?php echo csrf_field(); ?> <?php echo method_field('delete'); ?>
                                                </form>
                                            </a>
                                            <a class="edit ms-2 bg-primary d-flex align-items-center justify-content-center"
                                                href="<?php echo e(route('deals.edit', $d->id)); ?>">
                                                <i class="fas fa-edit text-white"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr class="align-middle">
                                <td colspan="<?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Admin')): ?> 6 <?php else: ?> 5 <?php endif; ?>" class="text-center">
                                    <b>
                                        No deals created
                                    </b>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $('.delete').on('click', function() {
            swal.fire({
                icon: 'warning',
                title: 'Confirm delete',
                text: 'Are you sure to proceed?',
                showCancelButton: true,
            }).then((result) => {
                if (result.isConfirmed) this.querySelector('form').submit()
            })


        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', [
    'title' => $title,
    'breadcrumbs' => $breadcrumbs,
    'addButton' => true,
    'btn' => [
        'text' => 'Add Deal',
        'link' => route('deals.create'),
    ],
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Suraqa\phh\resources\views/dashboard/deals/index.blade.php ENDPATH**/ ?>