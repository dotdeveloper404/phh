<!DOCTYPE html>
<html lang="en">

<!--begin::Head-->

<head>
    <title><?php echo $__env->yieldContent('title'); ?> | <?php echo e(config('app.name')); ?></title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="shortcut icon" href="<?php echo e(asset('dashboard-assets/media/logos/favicon.ico')); ?>" />

    <!--begin::Fonts(mandatory for all pages)-->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Inter:300,400,500,600,700" />
    <!--end::Fonts-->

    <!--begin::Global Stylesheets Bundle(mandatory for all pages)-->
    <link href="<?php echo e(asset('dashboard-assets/plugins/global/plugins.bundle.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('dashboard-assets/css/style.bundle.css')); ?>" rel="stylesheet" type="text/css" />
    <!--end::Global Stylesheets Bundle-->

    <style>
        body {
            background-image: url(<?php echo e(asset('assets/images/bg4.jpg')); ?>);
        }
    </style>

    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
</head>
<!--end::Head-->

<!--begin::Body-->

<body id="kt_body" class="app-blank app-blank bgi-size-cover bgi-position-center bgi-no-repeat">

    <!--begin::Root-->
    <div class="d-flex flex-column flex-root justify-content-center" id="kt_app_root">

        <?php echo $__env->yieldContent('content'); ?>

    </div>
    <!--end::Root-->

    <!--begin::Global Javascript Bundle(mandatory for all pages)-->
    <script src="<?php echo e(asset('dashboard-assets/plugins/global/plugins.bundle.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard-assets/js/scripts.bundle.js')); ?>"></script>
    <!--end::Global Javascript Bundle-->

</body>
<!--end::Body-->

</html>
<?php /**PATH D:\Suraqa\phh\resources\views/layouts/guest.blade.php ENDPATH**/ ?>