

<?php $__env->startSection('title', 'Cart'); ?>

<?php $__env->startSection('content'); ?>
    <section class="breadcrum-header">
        <div class="container">
            <div class="row">
                <div class="col-xxl-12 col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <h1>Cart</h1>
                </div>
            </div>
        </div>
    </section>

    <section class="cart-section contactus-section">
        <div class="container">
            <div class="row">
                <?php if($message = Session::get('success')): ?>
                    <div class="col-12 mb-5">
                        <div class="alert alert-success alert-dismissible" role="alert">
                            <?php echo e($message); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="col-xxl-12 col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th></th>
                                    <th>Name</th>
                                    <th>Price</th>
                                    <th>Quantity</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr class="align-middle">
                                        <td>
                                            <img src="<?php echo e(asset("uploads/{$item->attributes->image}")); ?>" alt="Thumbnail" style="width: 70px;height: 70px;">
                                        </td>
                                        <td>
                                            <?php echo e($item->name); ?>

                                        </td>
                                        <td>
                                            <?php echo e($item->price); ?>

                                        </td>
                                        <td>
                                            <form action="<?php echo e(route('cart.update')); ?>" method="POST" class="d-flex">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                                                <input type="number" name="quantity" value="<?php echo e($item->quantity); ?>" class="form-control w-25 me-3" />
                                                <button type="submit" class="btn_update_to_cart btn btn-primary">Update</button>
                                            </form>
                                        </td>
                                        <td>
                                            <form action="<?php echo e(route('cart.remove')); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" value="<?php echo e($item->id); ?>" name="id">
                                                <button class="btn btn-danger">x</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="5" class="text-center">No items added to cart</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <div style="float:right;">
                            <div class="text-end">
                                <b>Total: $<?php echo e(Cart::getTotal()); ?></b>
                            </div>

                            <div class="d-flex">
                                <button class="btn btn-danger me-2" onclick="$('#clear-cart').submit()">Remove All Cart</button>
                                <a href="<?php echo e(route('checkout')); ?>" class="btn btn-primary">Checkout</a>
                            </div>
                            <form action="<?php echo e(route('cart.clear')); ?>" method="POST" id="clear-cart"><?php echo csrf_field(); ?></form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.deals-section','data' => ['deals' => $deals]] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('deals-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['deals' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($deals)]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php if(session()->has('error')): $__env->startPush( 'scripts'); ?>
    <script>
        $(function() {
            swal.fire({
                icon: 'error',
                title: 'Error',
                text: "<?php echo e(session()->get('error')); ?>"
            })
        })
    </script>
<?php $__env->stopPush(); endif; ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Suraqa\phh\resources\views/frontend/cart.blade.php ENDPATH**/ ?>