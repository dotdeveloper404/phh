<div class="table-responsive">
    <table class="table table-striped">
        <thead>
            <tr>
                <th>#</th>
                <th></th>
                <th>Name</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Sub Total</th>
            </tr>
        </thead>
        <tbody>
            

            
        </tbody>
    </table>
</div>
<?php /**PATH D:\Suraqa\phh\resources\views/components/order-details-table.blade.php ENDPATH**/ ?>